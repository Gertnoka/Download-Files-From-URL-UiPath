﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : EN.FileDownloader.Properties.Resources
    {
    }
}