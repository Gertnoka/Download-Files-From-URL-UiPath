namespace EN.FileDownloader.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for DownloadFileViaURLDesigner.xaml
    /// </summary>
    public partial class DownloadFileViaURLDesigner
    {
        public DownloadFileViaURLDesigner()
        {
            InitializeComponent();
        }
    }
}
