using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using EN.FileDownloader.Activities.Design.Designers;
using EN.FileDownloader.Activities.Design.Properties;

namespace EN.FileDownloader.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(DownloadFileViaURL), categoryAttribute);
            builder.AddCustomAttributes(typeof(DownloadFileViaURL), new DesignerAttribute(typeof(DownloadFileViaURLDesigner)));
            builder.AddCustomAttributes(typeof(DownloadFileViaURL), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
