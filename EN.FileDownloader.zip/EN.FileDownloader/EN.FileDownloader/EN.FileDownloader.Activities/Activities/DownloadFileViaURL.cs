using System;
using System.Activities;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using EN.FileDownloader.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace EN.FileDownloader.Activities
{
    [LocalizedDisplayName(nameof(Resources.DownloadFileViaURL_DisplayName))]
    [LocalizedDescription(nameof(Resources.DownloadFileViaURL_Description))]
    public class DownloadFileViaURL : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.DownloadFileViaURL_FileURL_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadFileViaURL_FileURL_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> FileURL { get; set; }

        [LocalizedDisplayName(nameof(Resources.DownloadFileViaURL_LocalPath_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadFileViaURL_LocalPath_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> LocalPath { get; set; }

        #endregion


        #region Constructors

        public DownloadFileViaURL()
        {
        }

        public static void downloadFile(string URL, string localPath)
        {
            WebClient webClient = new WebClient();
            webClient.DownloadFile($"{URL}", localPath);
        }
        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (FileURL == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(FileURL)));
            if (LocalPath == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(LocalPath)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var fileURL = FileURL.Get(context);
            var localPath = LocalPath.Get(context);
    
            
            // Add execution logic HERE
            DownloadFileViaURL.downloadFile(fileURL, localPath);

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }
}

