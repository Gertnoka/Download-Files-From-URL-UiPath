﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : EN.FileDownloader.Activities.Properties.Resources
    {
    }
}